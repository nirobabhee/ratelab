-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 05:06 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `viserlab_revlab`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `username`, `email_verified_at`, `image`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'admin@site.com', 'admin', NULL, '62284fc0a11a51646809024.jpeg', '$2y$10$2qcOUKrDIUqyyCklvHp7IO8fGNcJ1gAXtxouTn1isZPHu6H8CfHPq', NULL, '2022-03-09 06:57:04');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT 0,
  `click_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_password_resets`
--

CREATE TABLE `admin_password_resets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `impression` int(11) NOT NULL DEFAULT 0,
  `click` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'pending=>0, Approved =>1, Rejected=>2',
  `avg_rating` double(5,2) NOT NULL DEFAULT 0.00,
  `admin_feedback` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_logs`
--

CREATE TABLE `email_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `mail_sender` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_sms_templates`
--

CREATE TABLE `email_sms_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `act` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subj` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortcodes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_status` tinyint(1) NOT NULL DEFAULT 1,
  `sms_status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_sms_templates`
--

INSERT INTO `email_sms_templates` (`id`, `act`, `name`, `subj`, `email_body`, `sms_body`, `shortcodes`, `email_status`, `sms_status`, `created_at`, `updated_at`) VALUES
(1, 'PASS_RESET_CODE', 'Password Reset', 'Password Reset', '<div>We have received a request to reset the password for your account on <b>{{time}} .<br></b></div><div>Requested From IP: <b>{{ip}}</b> using <b>{{browser}}</b> on <b>{{operating_system}} </b>.</div><div><br></div><br><div><div><div>Your account recovery code is:&nbsp;&nbsp; <font size=\"6\"><b>{{code}}</b></font></div><div><br></div></div></div><div><br></div><div><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><br>', 'Your account recovery code is: {{code}}', ' {\"code\":\"Password Reset Code\",\"ip\":\"IP of User\",\"browser\":\"Browser of User\",\"operating_system\":\"Operating System of User\",\"time\":\"Request Time\"}', 1, 1, '2019-09-24 23:04:05', '2021-01-06 00:49:06'),
(2, 'PASS_RESET_DONE', 'Password Reset Confirmation', 'You have Reset your password', '<div><p>\r\n    You have successfully reset your password.</p><p>You changed from&nbsp; IP: <b>{{ip}}</b> using <b>{{browser}}</b> on <b>{{operating_system}}&nbsp;</b> on <b>{{time}}</b></p><p><b><br></b></p><p><font color=\"#FF0000\"><b>If you did not changed that, Please contact with us as soon as possible.</b></font><br></p></div>', 'Your password has been changed successfully', '{\"ip\":\"IP of User\",\"browser\":\"Browser of User\",\"operating_system\":\"Operating System of User\",\"time\":\"Request Time\"}', 1, 1, '2019-09-24 23:04:05', '2020-03-07 10:23:47'),
(3, 'EVER_CODE', 'Email Verification', 'Please verify your email address', '<div><br></div><div>Thanks For join with us. <br></div><div>Please use below code to verify your email address.<br></div><div><br></div><div>Your email verification code is:<font size=\"6\"><b> {{code}}</b></font></div>', 'Your email verification code is: {{code}}', '{\"code\":\"Verification code\"}', 1, 1, '2019-09-24 23:04:05', '2021-01-03 23:35:10'),
(4, 'SVER_CODE', 'SMS Verification ', 'Please verify your phone', 'Your phone verification code is: {{code}}', 'Your phone verification code is: {{code}}', '{\"code\":\"Verification code\"}', 0, 1, '2019-09-24 23:04:05', '2020-03-08 01:28:52'),
(16, 'ADMIN_SUPPORT_REPLY', 'Support Ticket Reply ', 'Reply Support Ticket', '<div><p><span style=\"font-size: 11pt;\" data-mce-style=\"font-size: 11pt;\"><strong>A member from our support team has replied to the following ticket:</strong></span></p><p><b><span style=\"font-size: 11pt;\" data-mce-style=\"font-size: 11pt;\"><strong><br></strong></span></b></p><p><b>[Ticket#{{ticket_id}}] {{ticket_subject}}<br><br>Click here to reply:&nbsp; {{link}}</b></p><p>----------------------------------------------</p><p>Here is the reply : <br></p><p> {{reply}}<br></p></div><div><br></div>', '{{subject}}\r\n\r\n{{reply}}\r\n\r\n\r\nClick here to reply:  {{link}}', '{\"ticket_id\":\"Support Ticket ID\", \"ticket_subject\":\"Subject Of Support Ticket\", \"reply\":\"Reply from Staff/Admin\",\"link\":\"Ticket URL For relpy\"}', 1, 1, '2020-06-08 18:00:00', '2020-05-04 02:24:40'),
(217, 'COMPANY_APPROVED', 'Company approved by admin.', 'Your company is approved by admin', '<div>The {{name}} has been approved successfully.</div>\r\n<div>By {{site}}</div>\r\n<div>Feedback: {{feedback}}</div>', '<div>The {{name}} has been approved successfully.</div><br>\r\n<div>By {{site}}</div>\r\n<div>Feedback: {{feedback}}</div>', '{\"Name\":\"Company Name\",\"Site\":\"Website name\",\"feedback\":\"Admin feedback\"}', 1, 1, '2019-09-14 19:14:22', '2022-03-02 06:43:03'),
(218, 'COMPANY_REJECTED', 'Company rejected by admin', 'Your company is rejected by admin', '\r\n<div>The {{name}} has been rejected.</div>\r\n<div>By {{site}}</div>\r\n<div>Feedback: {{feedback}}</div>', '<div>The {{name}} has been rejected.</div>\r\n<div>By {{site}}</div>\r\n<div>Feedback: {{feedback}}</div>', '{\"Name\":\"Company Name\",\"Site\":\"Website name\",\"feedback\":\"Admin Feedback\"}', 1, 1, '2019-09-14 19:14:22', '2019-11-10 09:07:12');

-- --------------------------------------------------------

--
-- Table structure for table `extensions`
--

CREATE TABLE `extensions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `act` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `script` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortcode` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'object',
  `support` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'help section',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=>enable, 2=>disable',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `extensions`
--

INSERT INTO `extensions` (`id`, `act`, `name`, `description`, `image`, `script`, `shortcode`, `support`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'tawk-chat', 'Tawk.to', 'Key location is shown bellow', 'tawky_big.png', '<script>\r\n                        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();\r\n                        (function(){\r\n                        var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];\r\n                        s1.async=true;\r\n                        s1.src=\"https://embed.tawk.to/{{app_key}}\";\r\n                        s1.charset=\"UTF-8\";\r\n                        s1.setAttribute(\"crossorigin\",\"*\");\r\n                        s0.parentNode.insertBefore(s1,s0);\r\n                        })();\r\n                    </script>', '{\"app_key\":{\"title\":\"App Key\",\"value\":\"------\"}}', 'twak.png', 0, NULL, '2019-10-18 23:16:05', '2021-05-18 05:37:12'),
(2, 'google-recaptcha2', 'Google Recaptcha 2', 'Key location is shown bellow', 'recaptcha3.png', '\r\n<script src=\"https://www.google.com/recaptcha/api.js\"></script>\r\n<div class=\"g-recaptcha\" data-sitekey=\"{{sitekey}}\" data-callback=\"verifyCaptcha\"></div>\r\n<div id=\"g-recaptcha-error\"></div>', '{\"sitekey\":{\"title\":\"Site Key\",\"value\":\"6Lfpm3cUAAAAAGIjbEJKhJNKS4X1Gns9ANjh8MfH\"}}', 'recaptcha.png', 0, NULL, '2019-10-18 23:16:05', '2022-03-08 09:55:58'),
(3, 'custom-captcha', 'Custom Captcha', 'Just Put Any Random String', 'customcaptcha.png', NULL, '{\"random_key\":{\"title\":\"Random String\",\"value\":\"SecureString\"}}', 'na', 0, NULL, '2019-10-18 23:16:05', '2022-03-08 09:56:02'),
(4, 'google-analytics', 'Google Analytics', 'Key location is shown bellow', 'google_analytics.png', '<script async src=\"https://www.googletagmanager.com/gtag/js?id={{app_key}}\"></script>\r\n                <script>\r\n                  window.dataLayer = window.dataLayer || [];\r\n                  function gtag(){dataLayer.push(arguments);}\r\n                  gtag(\"js\", new Date());\r\n                \r\n                  gtag(\"config\", \"{{app_key}}\");\r\n                </script>', '{\"app_key\":{\"title\":\"App Key\",\"value\":\"------\"}}', 'ganalytics.png', 0, NULL, NULL, '2021-05-04 10:19:12');

-- --------------------------------------------------------

--
-- Table structure for table `frontends`
--

CREATE TABLE `frontends` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `data_keys` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_values` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frontends`
--

INSERT INTO `frontends` (`id`, `data_keys`, `data_values`, `created_at`, `updated_at`) VALUES
(1, 'seo.data', '{\"seo_image\":\"1\",\"keywords\":[\"review\",\"rating\",\"company\",\"ltd\",\"business review\",\"business rating\"],\"description\":\"RateLab is a business review platform. Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi dolorem itaque laudantium aut, quibusdam amet, nemo quaerat, fuga facere corrupti quos dolorum. Blanditiis, exercitationem quia aliquam sit temporibus enim aspernatur repudiandae inventore, corporis vero quo animi beatae laborum ullam distinctio vel laudantium modi! Libero perferendis necessitatibus saepe deleniti illo officiis.\",\"social_title\":\"RateLab - Business Review Platform\",\"social_description\":\"RateLab is a business review platform. Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi dolorem itaque laudantium aut, quibusdam amet, nemo quaerat, fuga facere corrupti quos dolorum. Blanditiis, exercitationem quia aliquam sit temporibus enim aspernatur repudiandae inventore, corporis vero quo animi beatae laborum ullam distinctio vel laudantium modi! Libero perferendis necessitatibus saepe deleniti illo officiis.\",\"image\":\"6228bfcf627c11646837711.png\"}', '2020-07-04 23:42:52', '2022-03-09 14:57:21'),
(25, 'blog.content', '{\"heading\":\"Our latest news\",\"subheading\":\"Blog Post\",\"button_name\":\"Read more\"}', '2020-10-28 00:51:34', '2022-02-24 09:54:56'),
(31, 'social_icon.element', '{\"title\":\"Facebook\",\"social_icon\":\"<i class=\\\"lab la-facebook\\\"><\\/i>\",\"url\":\"https:\\/\\/www.facebook.com\\/\"}', '2020-11-12 04:07:30', '2022-02-13 12:24:33'),
(39, 'banner.content', '{\"has_image\":\"1\",\"heading\":\"Accelerate brand growth with Reviews and Loyalty\",\"subheading\":\"Read reviews. Write reviews. Find companies.\",\"image\":\"6208d5c567d691644746181.jpg\"}', '2021-05-02 06:09:30', '2022-02-20 05:32:20'),
(41, 'cookie.data', '{\"link\":\"policy\\/privacy-policy\\/42\",\"description\":\"We may use cookies or any other tracking technologies when you visit our website, including any other media form, mobile website, or mobile application related or connected to help customize the Site and improve your experience.\",\"status\":1}', '2020-07-04 23:42:52', '2022-03-08 06:05:52'),
(42, 'policy_pages.element', '{\"title\":\"Privacy Policy\",\"details\":\"<div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">What information do we collect?<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We gather data from you when you register on our site, submit a request, buy any services, react to an overview, or round out a structure. At the point when requesting any assistance or enrolling on our site, as suitable, you might be approached to enter your: name, email address, or telephone number. You may, nonetheless, visit our site anonymously.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">How do we protect your information?<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">All provided delicate\\/credit data is sent through Stripe.<br \\/>After an exchange, your private data (credit cards, social security numbers, financials, and so on) won\'t be put away on our workers.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Do we disclose any information to outside parties?<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We don\'t sell, exchange, or in any case move to outside gatherings by and by recognizable data. This does exclude confided in outsiders who help us in working our site, leading our business, or adjusting you, since those gatherings consent to keep this data private. We may likewise deliver your data when we accept discharge is suitable to follow the law, implement our site strategies, or ensure our own or others\' rights, property, or wellbeing.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Children\'s Online Privacy Protection Act Compliance<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We are consistent with the prerequisites of COPPA (Children\'s Online Privacy Protection Act), we don\'t gather any data from anybody under 13 years old. Our site, items, and administrations are completely coordinated to individuals who are in any event 13 years of age or more established.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Changes to our Privacy Policy<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">If we decide to change our privacy policy, we will post those changes on this page.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">How long we retain your information?<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">At the point when you register for our site, we cycle and keep your information we have about you however long you don\'t erase the record or withdraw yourself (subject to laws and guidelines).<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">What we don\\u2019t do with your data<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We don\'t and will never share, unveil, sell, or in any case give your information to different organizations for the promoting of their items or administrations.<\\/p><\\/div>\"}', '2021-06-09 08:50:42', '2021-06-09 08:50:42'),
(43, 'policy_pages.element', '{\"title\":\"Terms of Service\",\"details\":\"<div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We claim all authority to dismiss, end, or handicap any help with or without cause per administrator discretion. This is a Complete independent facilitating, on the off chance that you misuse our ticket or Livechat or emotionally supportive network by submitting solicitations or protests we will impair your record. The solitary time you should reach us about the seaward facilitating is if there is an issue with the worker. We have not many substance limitations and everything is as per laws and guidelines. Try not to join on the off chance that you intend to do anything contrary to the guidelines, we do check these things and we will know, don\'t burn through our own and your time by joining on the off chance that you figure you will have the option to sneak by us and break the terms.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><ul class=\\\"font-18\\\" style=\\\"padding-left:15px;list-style-type:disc;font-size:18px;\\\"><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Configuration requests - If you have a fully managed dedicated server with us then we offer custom PHP\\/MySQL configurations, firewalls for dedicated IPs, DNS, and httpd configurations.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Software requests - Cpanel Extension Installation will be granted as long as it does not interfere with the security, stability, and performance of other users on the server.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Emergency Support - We do not provide emergency support \\/ Phone Support \\/ LiveChat Support. Support may take some hours sometimes.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Webmaster help - We do not offer any support for webmaster related issues and difficulty including coding, &amp; installs, Error solving. if there is an issue where a library or configuration of the server then we can help you if it\'s possible from our end.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Backups - We keep backups but we are not responsible for data loss, you are fully responsible for all backups.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">We Don\'t support any child porn or such material.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">No spam-related sites or material, such as email lists, mass mail programs, and scripts, etc.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">No harassing material that may cause people to retaliate against you.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">No phishing pages.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">You may not run any exploitation script from the server. reason can be terminated immediately.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">If Anyone attempting to hack or exploit the server by using your script or hosting, we will terminate your account to keep safe other users.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Malicious Botnets are strictly forbidden.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Spam, mass mailing, or email marketing in any way are strictly forbidden here.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Malicious hacking materials, trojans, viruses, &amp; malicious bots running or for download are forbidden.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Resource and cronjob abuse is forbidden and will result in suspension or termination.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Php\\/CGI proxies are strictly forbidden.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">CGI-IRC is strictly forbidden.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">No fake or disposal mailers, mass mailing, mail bombers, SMS bombers, etc.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">NO CREDIT OR REFUND will be granted for interruptions of service, due to User Agreement violations.<\\/li><\\/ul><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Terms &amp; Conditions for Users<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">Before getting to this site, you are consenting to be limited by these site Terms and Conditions of Use, every single appropriate law, and guidelines, and concur that you are answerable for consistency with any material neighborhood laws. If you disagree with any of these terms, you are restricted from utilizing or getting to this site.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Support<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">Whenever you have downloaded our item, you may get in touch with us for help through email and we will give a valiant effort to determine your issue. We will attempt to answer using the Email for more modest bug fixes, after which we will refresh the center bundle. Content help is offered to confirmed clients by Tickets as it were. Backing demands made by email and Livechat.<\\/p><p class=\\\"my-3 font-18 font-weight-bold\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">On the off chance that your help requires extra adjustment of the System, at that point, you have two alternatives:<\\/p><ul class=\\\"font-18\\\" style=\\\"padding-left:15px;list-style-type:disc;font-size:18px;\\\"><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Hang tight for additional update discharge.<\\/li><li style=\\\"margin-top:0px;margin-right:0px;margin-left:0px;\\\">Or on the other hand, enlist a specialist (We offer customization for extra charges).<\\/li><\\/ul><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Ownership<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">You may not guarantee scholarly or selective possession of any of our items, altered or unmodified. All items are property, we created them. Our items are given \\\"with no guarantees\\\" without guarantee of any sort, either communicated or suggested. On no occasion will our juridical individual be subject to any harms including, however not restricted to, immediate, roundabout, extraordinary, accidental, or significant harms or different misfortunes emerging out of the utilization of or powerlessness to utilize our items.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Warranty<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We don\'t offer any guarantee or assurance of these Services in any way. When our Services have been modified we can\'t ensure they will work with all outsider plugins, modules, or internet browsers. Program similarity ought to be tried against the show formats on the demo worker. If you don\'t mind guarantee that the programs you use will work with the component, as we can not ensure that our systems will work with all program mixes.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Unauthorized\\/Illegal Usage<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">You may not utilize our things for any illicit or unapproved reason or may you, in the utilization of the stage, disregard any laws in your locale (counting yet not restricted to copyright laws) just as the laws of your nation and International law. Specifically, it is disallowed to utilize the things on our foundation for pages that advance: brutality, illegal intimidation, hard sexual entertainment, bigotry, obscenity content or warez programming joins.<br \\/><br \\/>You can\'t imitate, copy, duplicate, sell, exchange or adventure any of our segment, utilization of the offered on our things, or admittance to the administration without the express composed consent by us or item proprietor.<br \\/><br \\/>Our Members are liable for all substance posted on the discussion and demo and movement that happens under your record.<br \\/><br \\/>We hold the chance of hindering your participation account quickly if we will think about a particularly not allowed conduct.<br \\/><br \\/>If you make a record on our site, you are liable for keeping up the security of your record, and you are completely answerable for all exercises that happen under the record and some other activities taken regarding the record. You should quickly inform us, of any unapproved employments of your record or some other penetrates of security.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Fiverr, Seoclerks Sellers Or Affiliates<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We do NOT ensure full SEO campaign conveyance within 24 hours. We make no assurance for conveyance time by any means. We give our best assessment to orders during the putting in of requests, anyway, these are gauges. We won\'t be considered liable for loss of assets, negative surveys or you being prohibited for late conveyance. If you are selling on a site that requires time touchy outcomes, utilize Our SEO Services at your own risk.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Payment\\/Refund Policy<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">No refund or cash back will be made. After a deposit has been finished, it is extremely unlikely to invert it. You should utilize your equilibrium on requests our administrations, Hosting, SEO campaign. You concur that once you complete a deposit, you won\'t document a debate or a chargeback against us in any way, shape, or form.<br \\/><br \\/>If you document a debate or chargeback against us after a deposit, we claim all authority to end every single future request, prohibit you from our site. False action, for example, utilizing unapproved or taken charge cards will prompt the end of your record. There are no special cases.<\\/p><\\/div><div class=\\\"mb-5\\\" style=\\\"color:rgb(111,111,111);font-family:Nunito, sans-serif;margin-bottom:3rem;\\\"><h3 class=\\\"mb-3\\\" style=\\\"font-weight:600;line-height:1.3;font-size:24px;font-family:Exo, sans-serif;color:rgb(54,54,54);\\\">Free Balance \\/ Coupon Policy<\\/h3><p class=\\\"font-18\\\" style=\\\"margin-right:0px;margin-left:0px;font-size:18px;\\\">We offer numerous approaches to get FREE Balance, Coupons and Deposit offers yet we generally reserve the privilege to audit it and deduct it from your record offset with any explanation we may it is a sort of misuse. If we choose to deduct a few or all of free Balance from your record balance, and your record balance becomes negative, at that point the record will naturally be suspended. If your record is suspended because of a negative Balance you can request to make a custom payment to settle your equilibrium to actuate your record.<\\/p><\\/div>\"}', '2021-06-09 08:51:18', '2021-06-09 08:51:18'),
(44, 'category.content', '{\"heading\":\"Browse Companies by Category\"}', '2022-02-13 09:01:20', '2022-02-15 07:10:36'),
(45, 'choose_reason.content', '{\"heading\":\"Why would you give a review of our platform\",\"subheading\":\"Why Revlab\"}', '2022-02-13 09:45:26', '2022-02-13 10:19:32'),
(46, 'choose_reason.element', '{\"title\":\"Trusted Platform\",\"description\":\"Animi corporis et exercitationem natus, dolore adipisci optio sunt, eum, voluptas minus laudantium aliquam pariatur in. Tenetur atque eligendi consequatur rem.\",\"icon\":\"<i class=\\\"fas fa-handshake fa-3x\\\"><\\/i>\"}', '2022-02-13 09:57:25', '2022-02-13 11:03:51'),
(48, 'choose_reason.element', '{\"title\":\"Loyalty and Rewards\",\"description\":\"Animi corporis et exercitationem natus, dolore adipisci optio sunt, eum, voluptas minus laudantium aliquam pariatur in. Tenetur atque eligendi consequatur rem.\",\"icon\":\"<i class=\\\"far fa-gem fa-3x\\\"><\\/i>\"}', '2022-02-13 09:59:35', '2022-02-13 11:03:57'),
(49, 'choose_reason.element', '{\"title\":\"Reviews and Ratings\",\"description\":\"Animi corporis et exercitationem natus, dolore adipisci optio sunt, eum, voluptas minus laudantium aliquam pariatur in. Tenetur atque eligendi consequatur rem.\",\"icon\":\"<i class=\\\"las la-star fa-3x\\\"><\\/i>\"}', '2022-02-13 10:00:03', '2022-02-13 11:04:03'),
(50, 'review.content', '{\"heading\":\"Recent Review\"}', '2022-02-13 10:17:30', '2022-02-13 10:17:30'),
(51, 'cta.content', '{\"heading\":\"Given review or Grow brand trust\",\"subheading\":\"Hic ipsum recusandae minima asperiores libero. Expedita consectetur tenetur itaque distinctio animi, officiis illum dolorem excepturi minus blanditiis nam porro dignissimos commodi numquam soluta quam.\"}', '2022-02-13 10:24:46', '2022-02-13 10:24:46'),
(52, 'cta.element', '{\"title\":\"Give Your Real Review\",\"description\":\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur fugiat iure, sunt rerum saepe odit atque porro exercitationem enim dolor asperiores. Aliquam quo, iure ullam sed perferendis corrupti odit earum atque porro exercitationem.\",\"icon\":\"<i class=\\\"fas fa-book-reader fa-3x\\\"><\\/i>\",\"url\":\"login\",\"button_name\":\"Join With Us\"}', '2022-02-13 10:26:56', '2022-02-24 08:42:49'),
(53, 'cta.element', '{\"title\":\"Show your brand trust.\",\"description\":\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur fugiat iure, sunt rerum saepe odit atque porro exercitationem enim dolor asperiores. Aliquam quo, iure ullam sed perferendis corrupti odit earum atque porro exercitationem.\",\"icon\":\"<i class=\\\"las la-hand-holding-heart fa-3x\\\"><\\/i>\",\"url\":\"register\",\"button_name\":\"Get Started\"}', '2022-02-13 10:55:15', '2022-02-14 10:46:53'),
(54, 'testimonial.content', '{\"heading\":\"What Client Says About Us\",\"subheading\":\"Our User Review\",\"has_image\":\"1\",\"image\":\"6209f930c79951644820784.jpg\"}', '2022-02-13 11:16:47', '2022-03-09 06:58:42'),
(55, 'testimonial.element', '{\"name\":\"Nirob 11\",\"address\":\"Animi, America\",\"quote\":\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur fugiat iure, sunt rerum saepe odit atque porro exercitationem enim dolor asperiores. Aliquam quo, iure ullam sed perferendis corrupti odit earum atque porro exercitationem.\",\"has_image\":\"1\",\"image\":\"6226f9da284f81646721498.jpg\"}', '2022-02-13 11:25:27', '2022-03-08 06:38:18'),
(56, 'testimonial.element', '{\"name\":\"David ABC\",\"address\":\"florida Texas America\",\"quote\":\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur fugiat iure, sunt rerum saepe odit atque porro exercitationem enim dolor asperiores. Aliquam quo, iure ullam sed perferendis corrupti odit earum atque porro exercitationem.\",\"has_image\":\"1\",\"image\":\"6226f9f4e93281646721524.jpg\"}', '2022-02-13 11:27:35', '2022-03-08 06:38:44'),
(57, 'testimonial.element', '{\"name\":\"Neymar Jr.\",\"address\":\"Barzil\",\"quote\":\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur fugiat iure, sunt rerum saepe odit atque porro exercitationem enim dolor asperiores. Aliquam quo, iure ullam sed perferendis corrupti odit earum atque porro exercitationem.\",\"has_image\":\"1\",\"image\":\"6226fa08e7faf1646721544.jpg\"}', '2022-02-13 11:30:28', '2022-03-08 06:39:04'),
(58, 'testimonial.element', '{\"name\":\"Messy\",\"address\":\"Argentina\",\"quote\":\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur fugiat iure, sunt rerum saepe odit atque porro exercitationem enim dolor asperiores. Aliquam quo, iure ullam sed perferendis corrupti odit earum atque porro exercitationem.\",\"has_image\":\"1\",\"image\":\"6226fa529b19f1646721618.jpg\"}', '2022-02-13 11:30:50', '2022-03-08 06:40:37'),
(60, 'social_icon.element', '{\"title\":\"Twitter\",\"social_icon\":\"<i class=\\\"lab la-twitter\\\"><\\/i>\",\"url\":\"https:\\/\\/www.twitter.com\\/\"}', '2022-02-13 12:25:07', '2022-02-13 12:25:07'),
(61, 'social_icon.element', '{\"title\":\"Instragram\",\"social_icon\":\"<i class=\\\"lab la-instagram\\\"><\\/i>\",\"url\":\"https:\\/\\/www.instragram.com\\/\"}', '2022-02-13 12:25:39', '2022-02-13 12:25:39'),
(62, 'social_icon.element', '{\"title\":\"Pinterest\",\"social_icon\":\"<i class=\\\"lab la-pinterest-p\\\"><\\/i>\",\"url\":\"https:\\/\\/www.pinterest.com\\/login\\/\"}', '2022-02-13 12:26:12', '2022-02-13 12:27:54'),
(63, 'social_icon.element', '{\"title\":\"Youtube\",\"social_icon\":\"<i class=\\\"lab la-youtube\\\"><\\/i>\",\"url\":\"https:\\/\\/www.youtube.com\\/\"}', '2022-02-13 12:26:33', '2022-02-13 12:26:34'),
(64, 'register.content', '{\"greeting\":\"Welcome to Revlab\",\"heading\":\"Create an Account\",\"register_button_name\":\"Sign up\",\"login_button_name\":\"Sign In\",\"has_image\":\"1\",\"image\":\"6209fd38d9a301644821816.jpg\"}', '2022-02-14 06:26:56', '2022-02-14 06:28:59'),
(65, 'login.content', '{\"greeting\":\"Welcome Back\",\"heading\":\"Sign in to your account\",\"has_image\":\"1\",\"image\":\"620a1ff02842d1644830704.jpg\"}', '2022-02-14 09:25:04', '2022-03-08 08:55:35'),
(66, 'contact.content', '{\"heading\":\"Contact Us\",\"note\":\"Write us a few word about what type of help do you need. Our support team will contact you within 1hr.\",\"button_name\":\"Send Message\"}', '2022-02-14 14:52:14', '2022-02-28 09:13:23'),
(67, 'contact.element', '{\"title\":\"Address\",\"icon\":\"<i class=\\\"las la-address-card\\\"><\\/i>\",\"content\":\"Uttara, Texas-1230, USA\"}', '2022-02-14 14:56:57', '2022-02-14 14:56:57'),
(68, 'contact.element', '{\"title\":\"Mobile\",\"icon\":\"<i class=\\\"las la-mobile\\\"><\\/i>\",\"content\":\"+88123456789\"}', '2022-02-14 14:57:46', '2022-02-14 14:57:46'),
(69, 'contact.element', '{\"title\":\"E-mail\",\"icon\":\"<i class=\\\"las la-envelope\\\"><\\/i>\",\"content\":\"demo.support@gmail.com\"}', '2022-02-14 14:58:07', '2022-02-14 14:58:29'),
(70, 'breadcum.content', '{\"has_image\":\"1\",\"image\":\"620ba356b424a1644929878.jpg\"}', '2022-02-15 12:57:58', '2022-02-15 12:57:58'),
(71, 'company_list_section.content', '{\"title\":\"Want to give a review?\",\"button_name\":\"Join with us\",\"link\":\"\\/revlab\\/login\"}', '2022-02-17 07:08:20', '2022-02-23 08:46:00'),
(72, 'faq.content', '{\"heading\":\"FAQ\'s\",\"subheading\":\"Asked Us If You Have Any Question?\",\"has_image\":\"1\",\"image\":\"621732f5ef3d31645687541.jpg\"}', '2022-02-24 07:25:41', '2022-02-24 07:25:42'),
(73, 'faq.element', '{\"question\":\"Why is Revlab?\",\"answer\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque porttitor in nisi non efficitur. Curabitur porta, arcu malesuada efficitur ultricies, lectus risus imperdiet orci, ut varius ante enim non risus. Duis volutpat orci eget vulputate sollicitudin. Vestibulum commodo est ut velit porttitor pretium. Integer aliquet arcu mauris, vel cursus elit pulvinar a. Duis ante dui, aliquam dapibus lobortis sed, dignissim nec justo. Morbi mattis quam at enim rhoncus, sit amet feugiat urna eleifend. Donec molestie iaculis velit, et sodales sem dignissim in. Mauris ac dignissim diam. In fringilla quis justo id lacinia. Nam ante sapien, porttitor sed varius eu, egestas sed justo. Aenean placerat velit eget arcu elementum placerat. Nam sollicitudin volutpat diam ac lacinia. Suspendisse nec augue et ante rutrum porttitor.\"}', '2022-02-24 07:26:56', '2022-02-24 07:26:56'),
(74, 'faq.element', '{\"question\":\"Why Choice Revlab is the best one ?\",\"answer\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque porttitor in nisi non efficitur. Curabitur porta, arcu malesuada efficitur ultricies, lectus risus imperdiet orci, ut varius ante enim non risus. Duis volutpat orci eget vulputate sollicitudin. Vestibulum commodo est ut velit porttitor pretium. Integer aliquet arcu mauris, vel cursus elit pulvinar a. Duis ante dui, aliquam dapibus lobortis sed, dignissim nec justo. Morbi mattis quam at enim rhoncus, sit amet feugiat urna eleifend. Donec molestie iaculis velit, et sodales sem dignissim in. Mauris ac dignissim diam. In fringilla quis justo id lacinia. Nam ante sapien, porttitor sed varius eu, egestas sed justo. Aenean placerat velit eget arcu elementum placerat. Nam sollicitudin volutpat diam ac lacinia. Suspendisse nec augue et ante rutrum porttitor.\"}', '2022-02-24 07:28:00', '2022-02-24 07:28:00'),
(75, 'faq.element', '{\"question\":\"How get growth my company?\",\"answer\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque porttitor in nisi non efficitur. Curabitur porta, arcu malesuada efficitur ultricies, lectus risus imperdiet orci, ut varius ante enim non risus. Duis volutpat orci eget vulputate sollicitudin. Vestibulum commodo est ut velit porttitor pretium. Integer aliquet arcu mauris, vel cursus elit pulvinar a. Duis ante dui, aliquam dapibus lobortis sed, dignissim nec justo. Morbi mattis quam at enim rhoncus, sit amet feugiat urna eleifend. Donec molestie iaculis velit, et sodales sem dignissim in. Mauris ac dignissim diam. In fringilla quis justo id lacinia. Nam ante sapien, porttitor sed varius eu, egestas sed justo. Aenean placerat velit eget arcu elementum placerat. Nam sollicitudin volutpat diam ac lacinia. Suspendisse nec augue et ante rutrum porttitor.\"}', '2022-02-24 07:29:06', '2022-02-24 07:29:06'),
(81, 'breadcrumb.content', '{\"has_image\":\"1\",\"image\":\"621c602ebd52e1646026798.jpg\"}', '2022-02-28 05:39:58', '2022-02-28 05:39:59'),
(82, 'footer.content', '{\"heading\":\"Footer\",\"description\":\"Dolor sit amet consectetur adipisicing elit. Eligendi illo consequuntur eaque. Quidem saepe molestiae ducimus maiores.\"}', '2022-02-28 06:49:22', '2022-02-28 06:49:22'),
(83, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Maecenas nisi libero, gravida eget pulvinar quis, faucibus in ipsum. Mauris maximus sagittis velit, et cursus arcu bibendum\",\"description\":\"<blockquote style=\\\"margin-bottom:0px;margin-left:40px;border:none;padding:0px;\\\"><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\"><span style=\\\"font-weight:bolder;\\\"><i><font size=\\\"6\\\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.<\\/font><\\/i><\\/span>\\u00a0Pellentesque porttitor in nisi non efficitur. Curabitur porta, arcu malesuada efficitur ultricies, lectus risus imperdiet orci, ut varius ante enim non risus. Duis volutpat orci eget vulputate sollicitudin. Vestibulum commodo est ut velit porttitor pretium. Integer aliquet arcu mauris, vel cursus elit pulvinar a. Duis ante dui, aliquam dapibus lobortis sed, dignissim nec justo. Morbi mattis quam at enim rhoncus, sit amet feugiat urna eleifend. Donec molestie iaculis velit, et sodales sem dignissim in. Mauris ac dignissim diam. In fringilla quis justo id lacinia. Nam ante sapien, porttitor sed varius eu, egestas sed justo. Aenean placerat velit eget arcu elementum placerat. Nam sollicitudin volutpat diam ac lacinia. Suspendisse nec augue et ante rutrum porttitor.<\\/p><\\/blockquote><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\"><span style=\\\"font-weight:bolder;\\\">Curabitur vulputate, enim vitae ultricies<\\/span>\\u00a0vulputate, velit magna tincidunt leo, sit amet facilisis enim turpis a purus. Quisque iaculis, diam ut pharetra luctus, tortor diam consectetur sem, eget finibus enim nisi ut sapien. Nulla et ante mattis, dapibus mi a, iaculis augue. Nullam efficitur ex vitae tellus pretium dictum. Proin eu metus nunc. Suspendisse potenti. Ut suscipit, odio quis ornare faucibus, libero velit consectetur turpis, vel vestibulum nunc justo vel urna. Nulla sagittis ultrices sapien, quis porta diam rutrum ut. Nullam congue mauris quis metus vestibulum pretium. Donec nec tempus mauris, a pellentesque augue. Cras iaculis metus non purus elementum, eu ullamcorper quam posuere. Quisque scelerisque dapibus neque, in porta ligula consequat non. Nunc diam orci, vulputate ut posuere ac, malesuada nec metus. Aliquam consectetur turpis lacus, at pellentesque ante ornare sed. Integer in finibus enim. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.<\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\">Proin laoreet lectus eget euismod bibendum. Nam auctor velit enim, at tincidunt felis gravida sit amet.<\\/p><blockquote style=\\\"margin-bottom:0px;margin-left:40px;border:none;padding:0px;\\\"><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-size:0.875rem;font-family:\'Open Sans\', Arial, sans-serif;\\\">\\u00a0Praesent molestie nulla risus, in varius nisl blandit vitae. Integer cursus sollicitudin ante, sit amet pharetra<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-family:\'Open Sans\', Arial, sans-serif;font-size:0.875rem;\\\">\\u00a0felis fermentum ac. Morbi facilisis malesuada gravida. Nullam leo enim, sollicitudin et luctus quis, lacinia a nulla.<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-family:impact;font-size:0.875rem;\\\">\\u00a0Maecenas nisi libero, gravida eget pulvinar quis, faucibus in ipsum. Mauris maximus sagittis velit, et cursus arcu bibendum at<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><font face=\\\"Open Sans, Arial, sans-serif\\\" style=\\\"font-size:0.875rem;\\\">.<\\/font><font face=\\\"impact\\\" style=\\\"font-size:0.875rem;\\\">\\u00a0Nullam sit amet pharetra lacus, in egestas velit. Nulla vehicula, eros vitae tristique lacinia, est enim ultricies mi, vitae auctor sem ex in magna.<\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><font face=\\\"Open Sans, Arial, sans-serif\\\" style=\\\"font-size:0.875rem;\\\">\\u00a0<\\/font><font face=\\\"impact\\\" style=\\\"font-size:0.875rem;\\\">Fusce posuere posuere sapien, in rutrum lectus molestie quis. Vestibulum tristique dictum aliquet.<\\/font><\\/p><\\/blockquote>\",\"image\":\"6228cb1532e231646840597.jpg\"}', '2022-02-28 07:14:45', '2022-03-09 09:43:17'),
(84, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Concerns over Bangladesh\'s biggest project under sanctions on Russia\",\"description\":\"<p style=\\\"margin-right:0px;margin-bottom:24px;margin-left:0px;padding:0px;color:rgb(34,47,58);font-family:Shonar, Vrinda, Arial, Helvetica, sans-serif;font-size:16px;\\\"><font style=\\\"vertical-align:inherit;\\\"><font style=\\\"vertical-align:inherit;\\\">One after another sanctions have been imposed on Russia since the Ukraine invasion.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">Russia\'s banking system has been rocked by sanctions imposed by Ukraine\'s allies, including the United States, the United Kingdom and Europe.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">The latest in a series of talks with some of the country\'s largest banks to shut down the international money transaction system Swift.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">Allies of the European Union, the United States and Ukraine have agreed.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">If it is implemented, Russia will have problems in financial transactions with different countries.<\\/font><\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:24px;margin-left:0px;padding:0px;color:rgb(34,47,58);font-family:Shonar, Vrinda, Arial, Helvetica, sans-serif;font-size:16px;\\\"><font style=\\\"vertical-align:inherit;\\\"><font style=\\\"vertical-align:inherit;\\\">In such a situation, there is concern about the work of Rooppur Nuclear Power Plant, the biggest project in Bangladesh.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">Rosatom, a Russian state-owned company, is implementing the Rs 1 lakh crore project.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">Under the supervision of this organization, 16 contractors of the country are implementing the project.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">One unit of this two-unit power project is scheduled to be commissioned next year.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">The other unit is targeted to be launched in 2024.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">Russian workers are working to complete the project on time.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">About four and a half thousand Russians are working in Rooppur.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">They have all the arrangements including accommodation in the project area of \\u200b\\u200bIshwardi upazila of Pabna.<\\/font><\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:24px;margin-left:0px;padding:0px;color:rgb(34,47,58);font-family:Shonar, Vrinda, Arial, Helvetica, sans-serif;font-size:16px;\\\"><font style=\\\"vertical-align:inherit;\\\"><font style=\\\"vertical-align:inherit;\\\">Project sources say Russia is financing the project as a loan.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">The bill of the contractor responsible for the implementation of the project is paid from Russia.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">The salaries of Russian workers are similarly paid.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">However, the salaries of Bangladeshi workers in this project are paid from here.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">Besides, equipment is also being brought from Russia.<\\/font><\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:24px;margin-left:0px;padding:0px;color:rgb(34,47,58);font-family:Shonar, Vrinda, Arial, Helvetica, sans-serif;font-size:16px;\\\"><font style=\\\"vertical-align:inherit;\\\"><font style=\\\"vertical-align:inherit;\\\">If the Russian banking system is severed from Swift, money transactions for the project could be complicated.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">In addition, Russia\'s financial crisis caused by the war has raised concerns about the financing of the entire project.<\\/font><\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:24px;margin-left:0px;padding:0px;color:rgb(34,47,58);font-family:Shonar, Vrinda, Arial, Helvetica, sans-serif;font-size:16px;\\\"><font style=\\\"vertical-align:inherit;\\\">Besides, if Russia\'s state-controlled Atomic Energy Corporation-Rosatom falls under any sanctions, the biggest project in the history of Bangladesh could fall into uncertainty.<\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:24px;margin-left:0px;padding:0px;color:rgb(34,47,58);font-family:Shonar, Vrinda, Arial, Helvetica, sans-serif;font-size:16px;\\\"><font style=\\\"vertical-align:inherit;\\\"><font style=\\\"vertical-align:inherit;\\\">However, those involved in the project say that at present the work of the project is progressing at a normal pace.\\u00a0<\\/font><font style=\\\"vertical-align:inherit;\\\">So far no problem.<\\/font><\\/font><\\/p>\",\"image\":\"6228cb2d6f5e01646840621.jpg\"}', '2022-02-28 07:16:19', '2022-03-09 09:43:41'),
(85, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Nothing can describe that feeling when you\'ve won a Test match with your team\'\",\"description\":\"<strong style=\\\"margin:0px;padding:0px;color:rgb(0,0,0);font-family:\'Open Sans\', Arial, sans-serif;font-size:14px;text-align:justify;\\\">Lorem Ipsum<\\/strong><span style=\\\"color:rgb(0,0,0);font-family:\'Open Sans\', Arial, sans-serif;font-size:14px;text-align:justify;\\\">\\u00a0is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum<\\/span><br \\/>\",\"image\":\"6228cb6c0f9821646840684.jpg\"}', '2022-02-28 07:17:07', '2022-03-09 09:44:44'),
(86, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Musk says Starlink active in Ukraine as Russian invasion disrupts internet\",\"description\":\"<p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin-right:0px;margin-bottom:32px;margin-left:0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">SAN FRANCISCO, Feb 26 (Reuters) - SpaceX billionaire Elon Musk said on Saturday that the company\'s Starlink satellite broadband service is available in Ukraine and SpaceX is sending more terminals to the country, whose internet has been disrupted due to the Russian invasion.<\\/p><p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin:32px 0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">\\\"Starlink service is now active in Ukraine. More terminals en route,\\\" Musk tweeted.<\\/p><p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin:32px 0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">He was responding to a tweet by a Ukraine government official who asked Musk to provide the embattled country with Starlink stations.<\\/p><div class=\\\"SpacingContainer__container___2pZeDX SpacingContainer__max-width___3kq0CX\\\" style=\\\"margin-left:auto;margin-right:auto;width:661.339px;max-width:1440px;color:rgb(0,0,0);font-family:\'Times New Roman\';font-size:medium;\\\"><div class=\\\"ad-slot__container___3rdCdV\\\"><p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin:32px 0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">\\u201c@elonmusk, while you try to colonize Mars \\u2014 Russia try to occupy Ukraine! While your rockets successfully land from space \\u2014 Russian rockets attack Ukrainian civil people!\\\" Ukraine\\u2019s vice prime minister, Mykhailo Fedorov, tweeted.<\\/p><p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin:32px 0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">Internet connectivity in Ukraine has been affected by the Russian invasion, particularly in the southern and eastern parts of the country where fighting has been heaviest, internet monitors said on Saturday.\\u00a0<a href=\\\"https:\\/\\/www.reuters.com\\/world\\/europe\\/internet-ukraine-disrupted-russian-troops-advance-2022-02-26\\/\\\" class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__medium___3mY4FC Text__large___1NuIuP Link__underline_default___1RrRWa\\\" style=\\\"margin:0px;padding:0px;line-height:1;letter-spacing:0px;font-size:20px;font-family:\'knowledge-medium\', Arial, sans-serif;color:rgb(64,64,64);\\\">read more<\\/a><\\/p><div class=\\\"SpacingContainer__container___2pZeDX SpacingContainer__max-width___3kq0CX\\\" style=\\\"margin-left:auto;margin-right:auto;width:661.339px;max-width:1440px;\\\"><div class=\\\"ad-slot__container___3rdCdV\\\"><div class=\\\"ad-slot__inner___2BzoBn\\\" style=\\\"max-width:100%;\\\"><div><\\/div><\\/div><\\/div><\\/div><p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin:32px 0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">While extremely costly to deploy, satellite technology can provide internet for people who live in rural or hard-to-serve places where fiber optic cables and cell towers do not reach. The technology can also be a critical backstop when hurricanes or other natural disasters disrupt communication.<\\/p><p class=\\\"Text__text___2vZwzq Text__dark-grey___1T5z1- Text__regular___3orWU3 Text__large___1NuIuP Body__base___3K85eE Body__large_body___1_XkH1 article-body__element___vulnXJ\\\" style=\\\"margin:32px 0px;padding:0px;line-height:1.6;font-size:20px;font-family:\'knowledge-regular\', Arial, sans-serif;color:rgb(64,64,64);max-width:720px;\\\">Musk said on Jan. 15 that SpaceX had 1,469 Starlink satellites active and 272 moving to operational orbits soon.<\\/p><div class=\\\"ad-slot__inner___2BzoBn native\\\" style=\\\"max-width:100%;\\\"><div class=\\\"ad-slot__slot___6W8Kxc\\\"><\\/div><\\/div><\\/div><\\/div>\",\"image\":\"6228cb7bd96f11646840699.jpg\"}', '2022-02-28 07:18:35', '2022-03-09 09:45:00'),
(87, 'forgot_password.content', '{\"heading\":\"Select Your Account\",\"subheading\":\"Enter your email or username and submit to reset your password.\",\"has_image\":\"1\",\"image\":\"621db45bb23bf1646113883.jpg\"}', '2022-03-01 05:51:23', '2022-03-08 09:25:57'),
(88, 'verification_code.content', '{\"heading\":\"Verify Your Account\",\"subheading\":\"A 6 digit verification code has been sent to your email please check your email and submit that code.\",\"has_image\":\"1\",\"image\":\"6227259db05901646732701.jpg\"}', '2022-03-08 09:44:24', '2022-03-08 09:45:02'),
(89, 'reset_password.content', '{\"heading\":\"Reset Password\",\"subheading\":\"You have confirmed your account. Now you can change the password. Please set a secure and strong password.\",\"has_image\":\"1\",\"image\":\"622726df0dd5b1646733023.jpg\"}', '2022-03-08 09:50:19', '2022-03-08 09:51:15'),
(90, 'email_authentication.content', '{\"heading\":\"Verify Your Email\",\"subheading\":\"A 6 digit verification code has been sent to your email please check your email and submit that code.\",\"has_image\":\"1\",\"image\":\"62272d66cfddc1646734694.jpg\"}', '2022-03-08 10:18:14', '2022-03-08 10:18:14'),
(91, 'mobile_authentication.content', '{\"heading\":\"Verify Your Mobile Number\",\"subheading\":\"A 6 digit verification code has been sent to your mobile please check your inbox and submit that code.\",\"has_image\":\"1\",\"image\":\"622735dd19f921646736861.jpg\"}', '2022-03-08 10:54:17', '2022-03-08 10:54:21');
INSERT INTO `frontends` (`id`, `data_keys`, `data_values`, `created_at`, `updated_at`) VALUES
(92, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Maecenas nisi libero, gravida eget pulvinar quis, faucibus in ipsum. Mauris maximus sagittis velit, et cursus arcu bibendum\",\"description\":\"<blockquote style=\\\"margin-bottom:0px;margin-left:40px;border:none;padding:0px;\\\"><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\"><span style=\\\"font-weight:bolder;\\\"><i><font size=\\\"6\\\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.<\\/font><\\/i><\\/span>\\u00a0Pellentesque porttitor in nisi non efficitur. Curabitur porta, arcu malesuada efficitur ultricies, lectus risus imperdiet orci, ut varius ante enim non risus. Duis volutpat orci eget vulputate sollicitudin. Vestibulum commodo est ut velit porttitor pretium. Integer aliquet arcu mauris, vel cursus elit pulvinar a. Duis ante dui, aliquam dapibus lobortis sed, dignissim nec justo. Morbi mattis quam at enim rhoncus, sit amet feugiat urna eleifend. Donec molestie iaculis velit, et sodales sem dignissim in. Mauris ac dignissim diam. In fringilla quis justo id lacinia. Nam ante sapien, porttitor sed varius eu, egestas sed justo. Aenean placerat velit eget arcu elementum placerat. Nam sollicitudin volutpat diam ac lacinia. Suspendisse nec augue et ante rutrum porttitor.<\\/p><\\/blockquote><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\"><span style=\\\"font-weight:bolder;\\\">Curabitur vulputate, enim vitae ultricies<\\/span>\\u00a0vulputate, velit magna tincidunt leo, sit amet facilisis enim turpis a purus. Quisque iaculis, diam ut pharetra luctus, tortor diam consectetur sem, eget finibus enim nisi ut sapien. Nulla et ante mattis, dapibus mi a, iaculis augue. Nullam efficitur ex vitae tellus pretium dictum. Proin eu metus nunc. Suspendisse potenti. Ut suscipit, odio quis ornare faucibus, libero velit consectetur turpis, vel vestibulum nunc justo vel urna. Nulla sagittis ultrices sapien, quis porta diam rutrum ut. Nullam congue mauris quis metus vestibulum pretium. Donec nec tempus mauris, a pellentesque augue. Cras iaculis metus non purus elementum, eu ullamcorper quam posuere. Quisque scelerisque dapibus neque, in porta ligula consequat non. Nunc diam orci, vulputate ut posuere ac, malesuada nec metus. Aliquam consectetur turpis lacus, at pellentesque ante ornare sed. Integer in finibus enim. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.<\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\">Proin laoreet lectus eget euismod bibendum. Nam auctor velit enim, at tincidunt felis gravida sit amet.<\\/p><blockquote style=\\\"margin-bottom:0px;margin-left:40px;border:none;padding:0px;\\\"><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-size:0.875rem;font-family:\'Open Sans\', Arial, sans-serif;\\\">\\u00a0Praesent molestie nulla risus, in varius nisl blandit vitae. Integer cursus sollicitudin ante, sit amet pharetra<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-family:\'Open Sans\', Arial, sans-serif;font-size:0.875rem;\\\">\\u00a0felis fermentum ac. Morbi facilisis malesuada gravida. Nullam leo enim, sollicitudin et luctus quis, lacinia a nulla.<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-family:impact;font-size:0.875rem;\\\">\\u00a0Maecenas nisi libero, gravida eget pulvinar quis, faucibus in ipsum. Mauris maximus sagittis velit, et cursus arcu bibendum at<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><font face=\\\"Open Sans, Arial, sans-serif\\\" style=\\\"font-size:0.875rem;\\\">.<\\/font><font face=\\\"impact\\\" style=\\\"font-size:0.875rem;\\\">\\u00a0Nullam sit amet pharetra lacus, in egestas velit. Nulla vehicula, eros vitae tristique lacinia, est enim ultricies mi, vitae auctor sem ex in magna.<\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><font face=\\\"Open Sans, Arial, sans-serif\\\" style=\\\"font-size:0.875rem;\\\">\\u00a0<\\/font><font face=\\\"impact\\\" style=\\\"font-size:0.875rem;\\\">Fusce posuere posuere sapien, in rutrum lectus molestie quis. Vestibulum tristique dictum aliquet.<\\/font><\\/p><\\/blockquote>\",\"image\":\"6228caa8e4b9e1646840488.jpeg\"}', '2022-03-09 09:41:28', '2022-03-09 09:41:29'),
(93, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Maecenas nisi libero, gravida eget pulvinar quis, faucibus in ipsum. Mauris maximus sagittis velit, et cursus arcu bibendum\",\"description\":\"<blockquote style=\\\"margin-bottom:0px;margin-left:40px;border:none;padding:0px;\\\"><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\"><span style=\\\"font-weight:bolder;\\\"><i><font size=\\\"6\\\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.<\\/font><\\/i><\\/span>\\u00a0Pellentesque porttitor in nisi non efficitur. Curabitur porta, arcu malesuada efficitur ultricies, lectus risus imperdiet orci, ut varius ante enim non risus. Duis volutpat orci eget vulputate sollicitudin. Vestibulum commodo est ut velit porttitor pretium. Integer aliquet arcu mauris, vel cursus elit pulvinar a. Duis ante dui, aliquam dapibus lobortis sed, dignissim nec justo. Morbi mattis quam at enim rhoncus, sit amet feugiat urna eleifend. Donec molestie iaculis velit, et sodales sem dignissim in. Mauris ac dignissim diam. In fringilla quis justo id lacinia. Nam ante sapien, porttitor sed varius eu, egestas sed justo. Aenean placerat velit eget arcu elementum placerat. Nam sollicitudin volutpat diam ac lacinia. Suspendisse nec augue et ante rutrum porttitor.<\\/p><\\/blockquote><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\"><span style=\\\"font-weight:bolder;\\\">Curabitur vulputate, enim vitae ultricies<\\/span>\\u00a0vulputate, velit magna tincidunt leo, sit amet facilisis enim turpis a purus. Quisque iaculis, diam ut pharetra luctus, tortor diam consectetur sem, eget finibus enim nisi ut sapien. Nulla et ante mattis, dapibus mi a, iaculis augue. Nullam efficitur ex vitae tellus pretium dictum. Proin eu metus nunc. Suspendisse potenti. Ut suscipit, odio quis ornare faucibus, libero velit consectetur turpis, vel vestibulum nunc justo vel urna. Nulla sagittis ultrices sapien, quis porta diam rutrum ut. Nullam congue mauris quis metus vestibulum pretium. Donec nec tempus mauris, a pellentesque augue. Cras iaculis metus non purus elementum, eu ullamcorper quam posuere. Quisque scelerisque dapibus neque, in porta ligula consequat non. Nunc diam orci, vulputate ut posuere ac, malesuada nec metus. Aliquam consectetur turpis lacus, at pellentesque ante ornare sed. Integer in finibus enim. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.<\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;font-family:\'Open Sans\', Arial, sans-serif;\\\">Proin laoreet lectus eget euismod bibendum. Nam auctor velit enim, at tincidunt felis gravida sit amet.<\\/p><blockquote style=\\\"margin-bottom:0px;margin-left:40px;border:none;padding:0px;\\\"><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-size:0.875rem;font-family:\'Open Sans\', Arial, sans-serif;\\\">\\u00a0Praesent molestie nulla risus, in varius nisl blandit vitae. Integer cursus sollicitudin ante, sit amet pharetra<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-family:\'Open Sans\', Arial, sans-serif;font-size:0.875rem;\\\">\\u00a0felis fermentum ac. Morbi facilisis malesuada gravida. Nullam leo enim, sollicitudin et luctus quis, lacinia a nulla.<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><span style=\\\"color:rgb(0,0,0);font-family:impact;font-size:0.875rem;\\\">\\u00a0Maecenas nisi libero, gravida eget pulvinar quis, faucibus in ipsum. Mauris maximus sagittis velit, et cursus arcu bibendum at<\\/span><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><font face=\\\"Open Sans, Arial, sans-serif\\\" style=\\\"font-size:0.875rem;\\\">.<\\/font><font face=\\\"impact\\\" style=\\\"font-size:0.875rem;\\\">\\u00a0Nullam sit amet pharetra lacus, in egestas velit. Nulla vehicula, eros vitae tristique lacinia, est enim ultricies mi, vitae auctor sem ex in magna.<\\/font><\\/p><p style=\\\"margin-right:0px;margin-bottom:15px;margin-left:0px;color:rgb(0,0,0);font-size:14px;padding:0px;text-align:justify;\\\"><font face=\\\"Open Sans, Arial, sans-serif\\\" style=\\\"font-size:0.875rem;\\\">\\u00a0<\\/font><font face=\\\"impact\\\" style=\\\"font-size:0.875rem;\\\">Fusce posuere posuere sapien, in rutrum lectus molestie quis. Vestibulum tristique dictum aliquet.<\\/font><\\/p><\\/blockquote>\",\"image\":\"6228cafb8709d1646840571.jpg\"}', '2022-03-09 09:42:51', '2022-03-09 09:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sitename` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cur_text` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'currency text',
  `cur_sym` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'currency symbol',
  `email_from` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_template` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_color` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_color` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_config` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'email configuration',
  `sms_config` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ev` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'email verification, 0 - dont check, 1 - check',
  `en` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'email notification, 0 - dont send, 1 - send',
  `sv` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'sms verication, 0 - dont check, 1 - check',
  `sn` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'sms notification, 0 - dont send, 1 - send',
  `force_ssl` tinyint(1) NOT NULL DEFAULT 0,
  `secure_password` tinyint(1) NOT NULL DEFAULT 0,
  `agree` tinyint(1) NOT NULL DEFAULT 0,
  `registration` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0: Off	, 1: On',
  `active_template` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sys_version` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `sitename`, `cur_text`, `cur_sym`, `email_from`, `email_template`, `sms_api`, `base_color`, `secondary_color`, `mail_config`, `sms_config`, `ev`, `en`, `sv`, `sn`, `force_ssl`, `secure_password`, `agree`, `registration`, `active_template`, `sys_version`, `created_at`, `updated_at`) VALUES
(1, 'RateLab', 'USD', '$', 'info@viserlab.com', '<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\r\n  <!--[if !mso]><!-->\r\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n  <!--<![endif]-->\r\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n  <title></title>\r\n  <style type=\"text/css\">\r\n.ReadMsgBody { width: 100%; background-color: #ffffff; }\r\n.ExternalClass { width: 100%; background-color: #ffffff; }\r\n.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }\r\nhtml { width: 100%; }\r\nbody { -webkit-text-size-adjust: none; -ms-text-size-adjust: none; margin: 0; padding: 0; }\r\ntable { border-spacing: 0; table-layout: fixed; margin: 0 auto;border-collapse: collapse; }\r\ntable table table { table-layout: auto; }\r\n.yshortcuts a { border-bottom: none !important; }\r\nimg:hover { opacity: 0.9 !important; }\r\na { color: #0087ff; text-decoration: none; }\r\n.textbutton a { font-family: \'open sans\', arial, sans-serif !important;}\r\n.btn-link a { color:#FFFFFF !important;}\r\n\r\n@media only screen and (max-width: 480px) {\r\nbody { width: auto !important; }\r\n*[class=\"table-inner\"] { width: 90% !important; text-align: center !important; }\r\n*[class=\"table-full\"] { width: 100% !important; text-align: center !important; }\r\n/* image */\r\nimg[class=\"img1\"] { width: 100% !important; height: auto !important; }\r\n}\r\n</style>\r\n\r\n\r\n\r\n  <table bgcolor=\"#414a51\" width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n    <tbody><tr>\r\n      <td height=\"50\"></td>\r\n    </tr>\r\n    <tr>\r\n      <td align=\"center\" style=\"text-align:center;vertical-align:top;font-size:0;\">\r\n        <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n          <tbody><tr>\r\n            <td align=\"center\" width=\"600\">\r\n              <!--header-->\r\n              <table class=\"table-inner\" width=\"95%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n                <tbody><tr>\r\n                  <td bgcolor=\"#0087ff\" style=\"border-top-left-radius:6px; border-top-right-radius:6px;text-align:center;vertical-align:top;font-size:0;\" align=\"center\">\r\n                    <table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n                      <tbody><tr>\r\n                        <td height=\"20\"></td>\r\n                      </tr>\r\n                      <tr>\r\n                        <td align=\"center\" style=\"font-family: \'Open sans\', Arial, sans-serif; color:#FFFFFF; font-size:16px; font-weight: bold;\">This is a System Generated Email</td>\r\n                      </tr>\r\n                      <tr>\r\n                        <td height=\"20\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n              <!--end header-->\r\n              <table class=\"table-inner\" width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n                  <td bgcolor=\"#FFFFFF\" align=\"center\" style=\"text-align:center;vertical-align:top;font-size:0;\">\r\n                    <table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                      <tbody><tr>\r\n                        <td height=\"35\"></td>\r\n                      </tr>\r\n                      <!--logo-->\r\n                      <tr>\r\n                        <td align=\"center\" style=\"vertical-align:top;font-size:0;\">\r\n                          <a href=\"#\">\r\n                            <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\" src=\"https://i.imgur.com/Z1qtvtV.png\" alt=\"img\">\r\n                          </a>\r\n                        </td>\r\n                      </tr>\r\n                      <!--end logo-->\r\n                      <tr>\r\n                        <td height=\"40\"></td>\r\n                      </tr>\r\n                      <!--headline-->\r\n                      <tr>\r\n                        <td align=\"center\" style=\"font-family: \'Open Sans\', Arial, sans-serif; font-size: 22px;color:#414a51;font-weight: bold;\">Hello {{fullname}} ({{username}})</td>\r\n                      </tr>\r\n                      <!--end headline-->\r\n                      <tr>\r\n                        <td align=\"center\" style=\"text-align:center;vertical-align:top;font-size:0;\">\r\n                          <table width=\"40\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n                            <tbody><tr>\r\n                              <td height=\"20\" style=\" border-bottom:3px solid #0087ff;\"></td>\r\n                            </tr>\r\n                          </tbody></table>\r\n                        </td>\r\n                      </tr>\r\n                      <tr>\r\n                        <td height=\"20\"></td>\r\n                      </tr>\r\n                      <!--content-->\r\n                      <tr>\r\n                        <td align=\"left\" style=\"font-family: \'Open sans\', Arial, sans-serif; color:#7f8c8d; font-size:16px; line-height: 28px;\">{{message}}</td>\r\n                      </tr>\r\n                      <!--end content-->\r\n                      <tr>\r\n                        <td height=\"40\"></td>\r\n                      </tr>\r\n              \r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td height=\"45\" align=\"center\" bgcolor=\"#f4f4f4\" style=\"border-bottom-left-radius:6px;border-bottom-right-radius:6px;\">\r\n                    <table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                      <tbody><tr>\r\n                        <td height=\"10\"></td>\r\n                      </tr>\r\n                      <!--preference-->\r\n                      <tr>\r\n                        <td class=\"preference-link\" align=\"center\" style=\"font-family: \'Open sans\', Arial, sans-serif; color:#95a5a6; font-size:14px;\">\r\n                          © 2021 <a href=\"#\">Website Name</a> . All Rights Reserved. \r\n                        </td>\r\n                      </tr>\r\n                      <!--end preference-->\r\n                      <tr>\r\n                        <td height=\"10\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n    <tr>\r\n      <td height=\"60\"></td>\r\n    </tr>\r\n  </tbody></table>', 'hi {{name}}, {{message}}', 'ffa92b', '1c629d', '{\"name\":\"php\"}', '{\"clickatell_api_key\":\"----------------------------\",\"infobip_username\":\"--------------\",\"infobip_password\":\"----------------------\",\"message_bird_api_key\":\"-------------------\",\"nexmo_api_key\":\"735a9da4\",\"nexmo_api_secret\":\"65DMdhUXIDkg1itC\",\"account_sid\":\"AC67afdacf2dacff5f163134883db92c24\",\"auth_token\":\"77726b242830fb28f52fb08c648dd7a6\",\"from\":\"+17739011523\",\"apiv2_key\":\"dfsfgdfgh\",\"name\":\"clickatell\"}', 0, 1, 0, 0, 0, 0, 0, 1, 'basic', NULL, NULL, '2022-03-09 15:06:37');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_align` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0: left to right text align, 1: right to left text align',
  `is_default` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0: not default language, 1: default language',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tempname` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'template name',
  `secs` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `slug`, `tempname`, `secs`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'HOME', 'home', 'templates.basic.', '[\"category\",\"choose_reason\",\"review\",\"cta\",\"testimonial\",\"blog\"]', 1, '2020-07-11 06:23:58', '2022-02-13 11:16:16'),
(4, 'Blog', 'blog', 'templates.basic.', NULL, 1, '2020-10-22 01:14:43', '2020-10-22 01:14:43'),
(5, 'Contact', 'contact', 'templates.basic.', NULL, 1, '2020-10-22 01:14:53', '2022-02-24 09:01:59');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `rating` tinyint(1) NOT NULL DEFAULT 0,
  `review` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_attachments`
--

CREATE TABLE `support_attachments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `support_message_id` int(10) UNSIGNED NOT NULL,
  `attachment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_messages`
--

CREATE TABLE `support_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `supportticket_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) DEFAULT 0,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ticket` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0: Open, 1: Answered, 2: Replied, 3: Closed',
  `priority` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = Low, 2 = medium, 3 = heigh',
  `last_reply` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_code` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'contains full address',
  `about` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0: banned, 1: active',
  `ev` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0: email unverified, 1: email verified',
  `sv` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0: sms unverified, 1: sms verified',
  `ver_code` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'stores verification code',
  `ver_code_send_at` datetime DEFAULT NULL COMMENT 'verification send time',
  `tsc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_logins`
--

CREATE TABLE `user_logins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_ip` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`username`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_logs`
--
ALTER TABLE `email_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_sms_templates`
--
ALTER TABLE `email_sms_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extensions`
--
ALTER TABLE `extensions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frontends`
--
ALTER TABLE `frontends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_attachments`
--
ALTER TABLE `support_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_messages`
--
ALTER TABLE `support_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- Indexes for table `user_logins`
--
ALTER TABLE `user_logins`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_logs`
--
ALTER TABLE `email_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_sms_templates`
--
ALTER TABLE `email_sms_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT for table `extensions`
--
ALTER TABLE `extensions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `frontends`
--
ALTER TABLE `frontends`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_attachments`
--
ALTER TABLE `support_attachments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_messages`
--
ALTER TABLE `support_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_logins`
--
ALTER TABLE `user_logins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
