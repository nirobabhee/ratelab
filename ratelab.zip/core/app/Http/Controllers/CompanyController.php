<?php

namespace App\Http\Controllers;
use App\Models\Category;
use App\Models\Company;
use App\Rules\FileTypeValidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class CompanyController extends Controller
{
    public function __construct()
    {
        $this->activeTemplate = activeTemplate();
    }

    public function index()
    {
        $pageTitle      = "My Companies";
        $emptyMessage   = "No company yet";
        $companies      = Company::where('user_id', auth()->id())->withAvg('reviews', 'rating')
            ->withCount('reviews')->latest()
            ->paginate(getPaginate());
        return view($this->activeTemplate . 'user.company.index', compact('pageTitle', 'emptyMessage', 'companies'));
    }

    public function create()
    {
        $categories = Category::where('status', 1)->orderBy('name')->get();
        $pageTitle = 'Add New Company';
        return view($this->activeTemplate . 'user.company.create', compact('pageTitle', 'categories'));
    }

    public function edit($id)
    {
        $company = Company::where('id', $id)->where('user_id', auth()->id())->firstOrFail();
        $categories = Category::orderBy('name')->get();
        $pageTitle = 'Edit Company';
        return view($this->activeTemplate . 'user.company.edit', compact('pageTitle', 'categories', 'company'));
    }


    public function store(Request $request){
        $this->validation($request);
        $company = new Company();
        $this->saveCompany($company, $request);
        $notify[] = ['success', 'Company added successfully'];
        return redirect()->route('user.company')->withNotify($notify);
    }

    public function update(Request $request, $id){
        $this->validation($request, $id, 'nullable');
        $company = Company::findOrFail($id);
        $this->saveCompany($company, $request);
        $notify[] = ['success', 'Company updated successfully'];
        return back()->withNotify($notify);
    }


    protected function validation($request, $id = 0, $imgValidation = 'required')
    {
        $request->validate(
            [
                'name'          => 'required|string|max:40|unique:companies,name,' . $id,
                'category'      => 'required|integer|exists:categories,id|gt:0',
                'image'         => [$imgValidation, 'image', new FileTypeValidate(['jpg', 'jpeg', 'png'])],
                'url'           => 'required|url',
                'email'         => 'required|email|unique:companies,email,' . $id,
                'address'       => 'required|string',
                'description'   => 'required|string',
                'tags'          => 'required|array|min:1',
                'tags.*'        => 'string|max:40',
            ]
        );
    }
    protected function saveCompany($company, $request)
    {
        if ($request->hasFile('image')) {
            $location       = imagePath()['company']['path'];
            $size           = imagePath()['company']['size'];
            $filename       = uploadImage($request->image, $location, $size, $company->image);
            $company->image  = $filename;
        }

        $company->category_id = $request->category;
        $company->user_id     = auth()->id();
        $company->name        = $request->name;
        $company->url         = $request->url;
        $company->email       = $request->email;
        $company->address     = $request->address;
        $company->description = $request->description;
        $company->tags        = $request->tags;
        $company->status      = 0;
        $company->save();
    }



    public function companyRating($id){
        $id   = Crypt::decrypt($id);
        $info = Company::where('id',$id)->where('status',1)->withAvg('reviews', 'rating')->withCount('reviews')->first();
        return response()->json([
            'rating'  => $info->avg_rating,
            'outOf'   => ' ('. $info->reviews_count .' Ratings)',
            'success' => true,
        ]);
    }
}
