@lang('Copyright') &copy; {{ \Carbon\Carbon::now()->format('Y') }} <a class="text--base" href="{{ route('home') }}">{{ @$general->sitename }}.</a> @lang('All Right Reserved')
