<?php

namespace App\Http\Controllers;

use App\Lib\GoogleAuthenticator;
use App\Models\Company;
use App\Models\GeneralSetting;
use App\Models\Review;
use App\Rules\FileTypeValidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class UserController extends Controller
{
    public function __construct()
    {
        $this->activeTemplate = activeTemplate();
    }

    public function home()
    {
        $pageTitle = 'Dashboard';
        $emptyMessage = 'No review yet';
        $reviews = auth()->user()->reviews()->with('company')->latest()->paginate(getPaginate());

        if(!$reviews->count()) {
            return redirect()->route('user.profile.setting');
        }

        return view($this->activeTemplate . 'user.dashboard', compact('pageTitle', 'reviews'));
    }

    public function updateReview(Request $request)
    {
        $request->validate(
            [
                'rating' => 'nullable|integer|min:1|max:5',
                'review' => 'required|string',
            ]
        );

        $review = Review::where('id', $request->id)->where('user_id', auth()->id())->firstOrFail();

        $review->rating = $request->rating ?? $review->rating;
        $review->review = $request->review;
        $review->save();

        $company = Company::where('id', $review->company_id)->first();
        $reviews = Review::where('company_id', $company->id)->get(['rating']);

        $company->avg_rating = $reviews->sum('rating') / $reviews->count();
        $company->save();

        $notify[] = ['success', 'Successfully review updated'];
        return back()->withNotify($notify);
    }


    public function deleteReview(Request $request)
    {
        $review     = Review::where('id', $request->id)->where('user_id', auth()->id())->firstOrFail();
        $company    = Company::find($review->company_id);
        $review->delete();
        $reviews = Review::where('company_id', $company->id)->get(['rating']);
        $company->avg_rating = 0;
        if ($reviews->count()) {
            $company->avg_rating = $reviews->sum('rating')  / $reviews->count();
        }
        $company->save();
        $notify[] = ['success', 'Successfully review deleted'];
        return back()->withNotify($notify);
    }


    public function profile()
    {
        $pageTitle = "Profile Setting";
        $user = Auth::user();
        return view($this->activeTemplate . 'user.profile_setting', compact('pageTitle', 'user'));
    }

    public function submitProfile(Request $request)
    {
        $request->validate([
            'firstname' => 'required|string|max:50',
            'lastname'  => 'required|string|max:50',
            'address'   => 'nullable|string|max:80',
            'state'     => 'nullable|string|max:80',
            'zip'       => 'nullable|string|max:40',
            'city'      => 'nullable|string|max:50',
            'image'     => ['image', new FileTypeValidate(['jpg', 'jpeg', 'png'])],
            'about'     => 'nullable|string|max:500',
        ], [
            'firstname.required' => 'First name field is required',
            'lastname.required' => 'Last name field is required'
        ]);

        $user = Auth::user();

        $in['firstname'] = $request->firstname;
        $in['lastname'] = $request->lastname;
        $in['address'] = [
            'address'   => $request->address,
            'state'     => $request->state,
            'zip'       => $request->zip,
            'country'   => @$user->address->country,
            'city'      => $request->city,
        ];

        if ($request->hasFile('image')) {
            $location = imagePath()['profile']['user']['path'];
            $size = imagePath()['profile']['user']['size'];
            $filename = uploadImage($request->image, $location, $size, $user->image);
            $in['image'] = $filename;
        }
        $in['about'] = $request->about;
        $user->fill($in)->save();
        $notify[] = ['success', 'Profile updated successfully'];
        return back()->withNotify($notify);
    }

    public function changePassword()
    {
        $pageTitle = 'Change password';
        return view($this->activeTemplate . 'user.password', compact('pageTitle'));
    }

    public function submitPassword(Request $request)
    {

        $password_validation = Password::min(6);
        $general = GeneralSetting::first();

        if ($general->secure_password) {
            $password_validation = $password_validation->mixedCase()->numbers()->symbols()->uncompromised();
        }

        $this->validate($request, [
            'current_password' => 'required',
            'password' => ['required', 'confirmed', $password_validation]
        ]);

        try {
            $user = auth()->user();
            if (Hash::check($request->current_password, $user->password)) {
                $password = Hash::make($request->password);
                $user->password = $password;
                $user->save();
                $notify[] = ['success', 'Password changed successfully'];
                return back()->withNotify($notify);
            } else {
                $notify[] = ['error', 'The password doesn\'t match!'];
                return back()->withNotify($notify);
            }
        } catch (\PDOException $e) {
            $notify[] = ['error', $e->getMessage()];
            return back()->withNotify($notify);
        }
    }
}
