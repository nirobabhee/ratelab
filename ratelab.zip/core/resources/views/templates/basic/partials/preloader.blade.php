<!-- preloader start -->
<div class="preloader">
    <div class="preloader__inner">
        <img src="{{ getImage(imagePath()['logoIcon']['path'] . '/logo.png') }}" alt="logo image"
            class="preloader__logo">
        <div class="preloader__ratings">
            <i class="las la-star"></i>
            <i class="las la-star"></i>
            <i class="las la-star"></i>
            <i class="las la-star"></i>
            <i class="las la-star"></i>
        </div>
    </div>
</div>
<!-- preloader end -->
